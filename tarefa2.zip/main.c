#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "base64.h"
#include "decode.h"


char* readFile(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo %s\n", filename);
        exit(1);
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* buffer = (char*)malloc(length + 1);
    if (buffer == NULL) {
        fclose(file);
        fprintf(stderr, "Falha na alocação de memória\n");
        exit(1);
    }

    fread(buffer, 1, length, file);
    fclose(file);
    buffer[length] = '\0';

    return buffer;
}

char* base64(char* plaintext) {
    // Tamanho do texto base64
    int plaintext_length = strlen(plaintext);

    // Determinar o tamanho do buffer necessário para armazenar o texto codificado
    // Isso é aproximadamente 4/3 do tamanho do texto original
    int encoded_length = (plaintext_length * 4) / 3;

    // Buffer para armazenar o texto codificado
    char* encoded_text = (char*)malloc(encoded_length + 1); // +1 para o caractere nulo terminador
    if (encoded_text == NULL) {
        fprintf(stderr, "Erro ao alocar memória para o texto codificado em base64\n");
        exit(1);
    }

    // Codificar o texto para base64
    bintob64(encoded_text, plaintext, plaintext_length);

    return encoded_text;
}

char* reverse(char* encoded_message) {
    // Tamanho do texto base64
    int encoded_length = strlen(encoded_message);

    // Determinar o tamanho do buffer necessário para armazenar o texto decodificado
    // Isso é aproximadamente 3/4 do tamanho do texto base64
    int decoded_length = (encoded_length * 3) / 4;

    // Buffer para armazenar o texto decodificado
    char* decoded_text = (char*)malloc(decoded_length + 1); // +1 para o caractere nulo terminador
    if (decoded_text == NULL) {
        fprintf(stderr, "Erro ao alocar memória para o texto decodificado\n");
        exit(1);
    }

    // Decodificar o texto base64 para binário
    if (b64tobin(decoded_text, encoded_message) == NULL) {
        fprintf(stderr, "Erro ao decodificar o texto base64\n");
        exit(1);
    }

    return decoded_text;
}

int main() {
    // Ler conteúdo do arquivo
    char* filename = "message.txt";
    char* plaintext = readFile(filename);

    // Codificar texto para base64
    char* encoded_message = base64(plaintext);

    // Imprimir resultados
    printf("Texto original: %s\n", plaintext);
    printf("Texto codificado em base64: %s\n", encoded_message);

    // Liberar memória alocada
    free(plaintext);
    free(encoded_message);

    return 0;
}
